const Colors = {
    accent500: "#9b59b6",
    accent800: "#8e44ad",
    primary300: "#ffffff",
    primary500: "#3498db",
    primary800: "#2980b9",
};

export default Colors;